;// Función de inicialización de la animación
document.addEventListener('DOMContentLoaded', function() {
    // Verificar si estamos en la página principal
    if (typeof starry_vars === 'undefined') {
        return;
    }

    // Configuración de Three.js
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
        alpha: true,
        antialias: true
    });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    
    // Añadir el canvas al overlay
    const overlay = document.getElementById('starry-overlay');
    if (!overlay) return;
    
    overlay.appendChild(renderer.domElement);

    // Crear grupo de estrellas
    const stars = new THREE.Group();
    const starGeometry = new THREE.BufferGeometry();
    const starPositions = [];
    const starSizes = [];
    const starOpacities = [];

    // Generar posición, tamaño y opacidad de las estrellas
    for (let i = 0; i < starry_vars.num_stars; i++) {
        // Posición aleatoria en 3D
        const x = (Math.random() - 0.5) * 2000;
        const y = (Math.random() - 0.5) * 2000;
        const z = (Math.random() - 0.5) * 2000 - 1000;
        
        starPositions.push(x, y, z);
        
        // Tamaño aleatorio
        const size = 0.1 + Math.random() * 0.5;
        starSizes.push(size);
        
        // Opacidad inicial
        starOpacities.push(1.0);
    }

    // Asignar datos al buffer
    starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('size', new THREE.Float32BufferAttribute(starSizes, 1));
    starGeometry.setAttribute('opacity', new THREE.Float32BufferAttribute(starOpacities, 1));

    // Material de estrellas
    const starMaterial = new THREE.PointsMaterial({
        color: starry_vars.star_color,
        size: 1,
        sizeAttenuation: true,
        transparent: true,
        opacity: 1,
        depthWrite: false
    });

    // Crear puntos de estrellas
    const starField = new THREE.Points(starGeometry, starMaterial);
    scene.add(starField);

    // Posicionar cámara
    camera.position.z = 500;

    // Variable para controlar la animación
    let animationComplete = false;

    // Función de animación
    function animate() {
        requestAnimationFrame(animate);
        
        if (!animationComplete) {
            // Mover estrellas hacia adelante
            const positions = starGeometry.attributes.position.array;
            const opacities = starGeometry.attributes.opacity.array;
            
            for (let i = 0; i < starry_vars.num_stars; i++) {
                const index = i * 3;
                
                // Mover estrella hacia adelante
                positions[index + 2] += 3;
                
                // Aplicar efecto de desvanecimiento cuando llegan cerca
                if (positions[index + 2] > 50) {
                    opacities[i] = Math.max(0, opacities[i] - starry_vars.fade_speed);
                }
                
                // Reiniciar estrella cuando sale de la vista
                if (positions[index + 2] > 100) {
                    positions[index] = (Math.random() - 0.5) * 2000;
                    positions[index + 1] = (Math.random() - 0.5) * 2000;
                    positions[index + 2] = -1000;
                    opacities[i] = 1.0;
                }
            }
            
            // Actualizar geometría
            starGeometry.attributes.position.needsUpdate = true;
            starGeometry.attributes.opacity.needsUpdate = true;
            
            // Verificar si la animación debe terminar
            if (starField.position.z > 200) {
                animationComplete = true;
                overlay.style.opacity = '0';
                setTimeout(() => {
                    if (overlay.parentNode) {
                        overlay.parentNode.removeChild(overlay);
                    }
                }, 1000);
            }
        }
        
        renderer.render(scene, camera);
    }

    // Iniciar animación
    animate();

    // Manejar redimensionamiento de ventana
    window.addEventListener('resize', function() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
});