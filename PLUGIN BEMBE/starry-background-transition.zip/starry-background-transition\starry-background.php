<?php
/**
 * Plugin Name: Starry Background Transition
 * Description: Muestra una animación de estrellas antes de cargar la interfaz
 * Version: 1.0
 * Author: Tu Nombre
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes
define('STARRY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('STARRY_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Cargar scripts y estilos
function starry_load_assets() {
    // Solo cargar en la página principal
    if (!is_admin()) {
        wp_enqueue_style('starry-css', STARRY_PLUGIN_URL . 'assets/css/styles.css', array(), '1.0');
        wp_enqueue_script('three-js', 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', array(), '1.0', true);
        wp_enqueue_script('starry-js', STARRY_PLUGIN_URL . 'assets/js/starry-animation.js', array('three-js'), '1.0', true);
        
        // Pasar datos a JavaScript
        wp_localize_script('starry-js', 'starry_vars', array(
            'plugin_url' => STARRY_PLUGIN_URL,
            'num_stars' => 7000,
            'star_color' => '#ffffff',
            'fade_speed' => 0.01
        ));
    }
}
add_action('wp_enqueue_scripts', 'starry_load_assets');

// Añadir overlay de animación
function starry_add_overlay() {
    if (!is_admin()) {
        echo '<div id="starry-overlay"></div>';
    }
}
add_action('wp_body_open', 'starry_add_overlay');