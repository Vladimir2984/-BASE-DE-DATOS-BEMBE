<?php
/**
 * Plugin Name: BEMBÉ Falling Flowers
 * Plugin URI: https://bembespb.ru
 * Description: Efecto visual de flores amarillas y hojas verdes cayendo suavemente en el fondo. Perfecto para escuelas de baile latinoamericano.
 * Version: 1.0.0
 * Author: MiniMax Agent
 * Author URI: https://bembespb.ru
 * License: GPL v2 or later
 * Text Domain: bembespb-falling-flowers
 */

// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

class BEMBESPB_Falling_Flowers {

    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'render_canvas'));
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Cargar scripts y estilos
     */
    public function enqueue_scripts() {
        // Solo en el frontend
        if (is_admin()) {
            return;
        }

        wp_enqueue_style(
            'bembespb-falling-flowers-css',
            plugin_dir_url(__FILE__) . 'css/falling-flowers.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'bembespb-falling-flowers-js',
            plugin_dir_url(__FILE__) . 'js/falling-flowers.js',
            array(),
            '1.0.0',
            true
        );

        // Pasar configuración al JavaScript
        wp_localize_script('bembespb-falling-flowers-js', 'fallingFlowersConfig', array(
            'flowerCount' => get_option('bembespb_flower_count', 15),
            'leafCount' => get_option('bembespb_leaf_count', 20),
            'speed' => get_option('bembespb_fall_speed', 'slow'),
            'enabled' => get_option('bembespb_flowers_enabled', 'yes'),
        ));
    }

    /**
     * Renderizar contenedor canvas
     */
    public function render_canvas() {
        if (is_admin()) {
            return;
        }

        $enabled = get_option('bembespb_flowers_enabled', 'yes');
        if ($enabled !== 'yes') {
            return;
        }
        ?>
        <div id="bembespb-falling-flowers-container" aria-hidden="true"></div>
        <?php
    }

    /**
     * Página de configuración en admin
     */
    public function add_settings_page() {
        add_options_page(
            'Flores Cayendo',
            'Flores Cayendo',
            'manage_options',
            'bembespb-falling-flowers',
            array($this, 'settings_page_html')
        );
    }

    /**
     * Registrar configuraciones
     */
    public function register_settings() {
        register_setting('bembespb_flowers_settings', 'bembespb_flowers_enabled');
        register_setting('bembespb_flowers_settings', 'bembespb_flower_count');
        register_setting('bembespb_flowers_settings', 'bembespb_leaf_count');
        register_setting('bembespb_flowers_settings', 'bembespb_fall_speed');
    }

    /**
     * HTML de la página de configuración
     */
    public function settings_page_html() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>Flores y Hojas Cayendo - Configuración</h1>
            <form method="post" action="options.php">
                <?php settings_fields('bembespb_flowers_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Activar efecto</th>
                        <td>
                            <select name="bembespb_flowers_enabled">
                                <option value="yes" <?php selected(get_option('bembespb_flowers_enabled', 'yes'), 'yes'); ?>>Sí</option>
                                <option value="no" <?php selected(get_option('bembespb_flowers_enabled'), 'no'); ?>>No</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Cantidad de flores</th>
                        <td>
                            <input type="number" name="bembespb_flower_count" value="<?php echo esc_attr(get_option('bembespb_flower_count', 15)); ?>" min="5" max="50" />
                            <p class="description">Recomendado: 10-20 para no sobrecargar</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Cantidad de hojas</th>
                        <td>
                            <input type="number" name="bembespb_leaf_count" value="<?php echo esc_attr(get_option('bembespb_leaf_count', 20)); ?>" min="5" max="50" />
                            <p class="description">Recomendado: 15-25 para un efecto natural</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Velocidad de caída</th>
                        <td>
                            <select name="bembespb_fall_speed">
                                <option value="very-slow" <?php selected(get_option('bembespb_fall_speed'), 'very-slow'); ?>>Muy lenta</option>
                                <option value="slow" <?php selected(get_option('bembespb_fall_speed', 'slow'), 'slow'); ?>>Lenta (recomendado)</option>
                                <option value="medium" <?php selected(get_option('bembespb_fall_speed'), 'medium'); ?>>Media</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Guardar cambios'); ?>
            </form>
        </div>
        <?php
    }
}

// Inicializar plugin
new BEMBESPB_Falling_Flowers();
