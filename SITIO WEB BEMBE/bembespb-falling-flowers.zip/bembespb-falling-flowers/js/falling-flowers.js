/**
 * BEMBÉ Falling Flowers - JavaScript
 * Flores amarillas y hojas verdes cayendo suavemente
 *
 * @version 1.0.0
 * @author MiniMax Agent
 */

(function() {
    'use strict';

    // Configuración por defecto
    const config = window.fallingFlowersConfig || {
        flowerCount: 15,
        leafCount: 20,
        speed: 'slow',
        enabled: 'yes'
    };

    // No ejecutar si está desactivado
    if (config.enabled !== 'yes') {
        return;
    }

    // Velocidades de animación (en segundos)
    const speedMap = {
        'very-slow': { min: 25, max: 40 },
        'slow': { min: 18, max: 30 },
        'medium': { min: 12, max: 20 }
    };

    // Obtener contenedor
    const container = document.getElementById('bembespb-falling-flowers-container');

    if (!container) {
        console.warn('BEMBÉ Falling Flowers: Contenedor no encontrado');
        return;
    }

    /**
     * Generar número aleatorio entre min y max
     */
    function random(min, max) {
        return Math.random() * (max - min) + min;
    }

    /**
     * Crear elemento de flor
     */
    function createFlower() {
        const flower = document.createElement('div');
        flower.className = 'falling-element falling-flower';

        // Variante aleatoria
        const variant = Math.floor(random(1, 4));
        if (variant > 1) {
            flower.classList.add('variant-' + variant);
        }

        // Posición inicial aleatoria
        flower.style.left = random(0, 100) + '%';
        flower.style.top = random(-10, -5) + '%';

        // Tamaño aleatorio
        const scale = random(0.6, 1.2);
        flower.style.transform = `scale(${scale})`;

        // Velocidad de caída
        const speeds = speedMap[config.speed] || speedMap['slow'];
        const duration = random(speeds.min, speeds.max);
        flower.style.animationDuration = duration + 's';

        // Retraso aleatorio para que no caigan todas juntas
        flower.style.animationDelay = random(0, 15) + 's';

        // Clase de velocidad
        flower.classList.add('speed-' + config.speed);

        // Opacidad variable para efecto de profundidad
        flower.style.opacity = random(0.3, 0.6);

        return flower;
    }

    /**
     * Crear elemento de hoja
     */
    function createLeaf() {
        const leaf = document.createElement('div');
        leaf.className = 'falling-element falling-leaf';

        // Variante aleatoria
        const variant = Math.floor(random(1, 4));
        if (variant > 1) {
            leaf.classList.add('variant-' + variant);
        }

        // Posición inicial aleatoria
        leaf.style.left = random(0, 100) + '%';
        leaf.style.top = random(-15, -5) + '%';

        // Tamaño aleatorio
        const scale = random(0.5, 1.0);
        leaf.style.transform = `scale(${scale})`;

        // Velocidad de caída (hojas un poco más rápidas)
        const speeds = speedMap[config.speed] || speedMap['slow'];
        const duration = random(speeds.min * 0.8, speeds.max * 0.9);
        leaf.style.animationDuration = duration + 's';

        // Retraso aleatorio
        leaf.style.animationDelay = random(0, 20) + 's';

        // Clase de velocidad
        leaf.classList.add('speed-' + config.speed);

        // Opacidad variable
        leaf.style.opacity = random(0.25, 0.5);

        return leaf;
    }

    /**
     * Regenerar elemento cuando termina la animación
     */
    function regenerateElement(element, type) {
        element.addEventListener('animationiteration', function() {
            // Nueva posición horizontal
            element.style.left = random(0, 100) + '%';

            // Nuevo tamaño
            const scale = random(0.5, 1.2);
            element.style.transform = `scale(${scale})`;

            // Nueva opacidad
            element.style.opacity = random(0.25, 0.6);
        });
    }

    /**
     * Inicializar flores y hojas
     */
    function init() {
        // Crear flores
        const flowerCount = parseInt(config.flowerCount) || 15;
        for (let i = 0; i < flowerCount; i++) {
            const flower = createFlower();
            regenerateElement(flower, 'flower');
            container.appendChild(flower);
        }

        // Crear hojas
        const leafCount = parseInt(config.leafCount) || 20;
        for (let i = 0; i < leafCount; i++) {
            const leaf = createLeaf();
            regenerateElement(leaf, 'leaf');
            container.appendChild(leaf);
        }

        console.log('BEMBÉ Falling Flowers: Iniciado con ' + flowerCount + ' flores y ' + leafCount + ' hojas');
    }

    /**
     * Pausar animación cuando la pestaña no está visible (rendimiento)
     */
    function handleVisibilityChange() {
        if (document.hidden) {
            container.style.animationPlayState = 'paused';
            container.querySelectorAll('.falling-element').forEach(el => {
                el.style.animationPlayState = 'paused';
            });
        } else {
            container.style.animationPlayState = 'running';
            container.querySelectorAll('.falling-element').forEach(el => {
                el.style.animationPlayState = 'running';
            });
        }
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);

    /**
     * Reducir elementos en móvil para mejor rendimiento
     */
    function handleResize() {
        const isMobile = window.innerWidth < 768;
        const elements = container.querySelectorAll('.falling-element');

        elements.forEach((el, index) => {
            if (isMobile) {
                // Ocultar la mitad de los elementos en móvil
                el.style.display = index % 2 === 0 ? 'block' : 'none';
            } else {
                el.style.display = 'block';
            }
        });
    }

    window.addEventListener('resize', debounce(handleResize, 250));

    /**
     * Función debounce para optimizar eventos
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Iniciar cuando el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            init();
            handleResize();
        });
    } else {
        init();
        handleResize();
    }

})();
