# Backup del Sitio bembespb.ru
## Fecha: 2026-03-23
## Página Principal

# Школа латиноамериканских танцев BEMBE - СПБ

## Estructura HTML y navegación

### Header (Encabezado)
- **Logo**: `/wp-content/themes/bembespb/assets/img/mal_logo_1x.png`
- **Nombre**: "Школа танцев" (Escuela de Baile)
- **Teléfono**: +7 (911) 113-99-58
- **Dirección**: Обводный канал, дом 46
- **Botón**: Solicitar llamada

### Menú de navegación:
1. Estilos de baile
2. Inscripciones a grupos
3. Horario
4. Precios
5. Profesores
6. Conciertos y masterclasses
7. Contactos

---

## Hero Section

**H1**: "# Танцы• Куба• Ритмы" (Bailes • Cuba • Ritmos)
**Subtítulo**: "BEMBé Escuela de bailes latinoamericanos en SPB"

**Ventajas:**
- Profesores profesionales
- Clases grupales e individuales
- Comunicación en vivo

**CTA**: "Dejar solicitud"

---

## Sección de estilos de baile (carrusel)

### 1. Bachata
- **Descripción**: Suave. Sensual. Fácil
- **Imagen**: `/wp-content/themes/bembespb/assets/img/Mal_cher_1x.png`

### 2. Salsa Cubana
- **Descripción**: Brillante. Apasionada. Intensa

### 3. Afro
- **Descripción**: Expresivo. Desenfrenado. Ardiente

---

## Sección de inscripciones abiertas

**Título**: "INSCRIPCIONES ABIERTAS:"

**Grupos:**
- Reparto (Репарто)
- Salsa principiantes

**Horario:**
- Reparto para todos los lunes de 20:00 a 22:00
- Salsa principiantes (desde medio año de experiencia) miércoles de 20:00 a 22:00

---

## Sección de enseñanza

**Título**: "Enseñanza de bailes latinoamericanos para adultos principiantes"

**Ventajas de la escuela:**
- Equipo de profesores profesionales y bailarines nativos de la cultura cubana
- Inmersión en la atmósfera de la cálida Cuba
- Ambiente lingüístico (español e inglés)
- LOS MEJORES PRECIOS en abonos en SPB
- Promociones, descuentos y regalos
- Hits musicales de Latinoamérica
- Nuevas amistades y salidas conjuntas
- Pasatiempo activo y divertido
- Estacionamiento, Wi-Fi, enfriador de agua, ducha
- Escuela en el distrito central de SPb

---

## Sección de estilos de baile (tarjetas)

| Dirección | Imagen | Enlace |
|-----------|--------|--------|
| Salsa Cubana | 105_oooo.plus_2x_1x.png | /dance-style/salsa/ |
| AFRO | 229_oooo.plus_2x_1x.png | /dance-style/afro/ |
| RUMBA CUBANA | 469_oooo.plus_2x_2x.png | /dance-style/rumba/ |
| REGGAETÓN | 442_oooo.plus_2x_1x.png | /dance-style/reggaeton/ |
| LADY STYLE | 894_oooo.plus_1_2x_1x.png | /dance-style/lady_style/ |
| BACHATA | 1229_oooo.plus_2x_1x.png | /dance-style/bachata/ |
| PERCUSIÓN | 1100_oooo.plus_2x_1x.png | /dance-style/proshkin/ |

---

## Sección de precios (tarifas)

**Título**: "Costo de estudiar en la escuela de bailes latinoamericanos BEMBE"

| Tipo | Precio | Condiciones |
|------|--------|-------------|
| Clase INDIVIDUAL | 600 rublos | Grupo 4-8 personas |
| 8 CLASES | 3900 rublos | Grupo 4-8 personas |
| 12 CLASES | 5200 rublos | Grupo 4-8 personas |
| Clase individual | 2500 rublos | A solas con el instructor |

---

## Formulario de inscripción

**Campos:**
- Nombre/datos de contacto
- Comentario
- Checkbox de consentimiento para procesamiento de datos personales (Ley Federal №152-ФЗ)
- Botón "Enviar"

---

## Footer

- Teléfono: +7 (911) 113-99-58
- Dirección: Обводный канал, дом 46
- Copyright: © 2020 Bembe
- Blog: /statii/

---

## Información técnica

- **Dominio**: bembespb.ru
- **Tema WordPress**: `/wp-content/themes/bembespb/`
- **Protocolo**: HTTPS
- **Esquema de colores**: Tonos latinoamericanos cálidos (naranja, rojo, amarillo)
