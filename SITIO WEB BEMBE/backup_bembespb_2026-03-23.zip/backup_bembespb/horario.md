# Backup - Horario de Clases BEMBÉ
## Fecha: 2026-03-23

# Расписание занятий (Horario de clases)

## Lunes (Пн)
- **20:00 – 22:00** - Reparto con Ildemar
- Imagen: `/wp-content/uploads/2022/04/15_2x_1x.png`

## Martes (Вт)
- **20:00 – 22:00** - AFROCUBANO (folclore afrocubano) con Iya Baval
- Imagen: `/wp-content/uploads/2022/04/13_1x.png`

## Miércoles (Ср)
- **20:00 – 22:00** - LADY STYLE con Iya Baval (Solo para mujeres)
- **20:00 – 22:00** - SALSA principiantes con Ildemar (¡Inscripción abierta!)
- Imagen: `/wp-content/uploads/2022/04/7_1x.png`

## Jueves (Чт)
- **20:00 – 22:00** - SALSA continuación con Ildemar (Grupo con más de un año de entrenamiento)
- Imagen: `/wp-content/uploads/2022/04/8_1x.png`

## Viernes (Пт)
- **Día libre** - La escuela no funciona
- Imagen: `/wp-content/uploads/2022/04/9_1x.png`
