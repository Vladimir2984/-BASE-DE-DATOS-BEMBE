# Backup - Precios BEMBÉ
## Fecha: 2026-03-23

# Стоимость обучения (Precios)

## Tarifas de Abonos

| Tipo | Precio | Condiciones |
|------|--------|-------------|
| Clase individual (РАЗОВОЕ занятие) | 600 ₽ | Grupo 4-8 personas, cualquier dirección, reagenda 24h antes |
| 8 Clases (8 ЗАНЯТИЙ) | 3900 ₽ | Grupo 4-8 personas, cualquier dirección |
| 12 Clases (12 ЗАНЯТИЙ) | 5200 ₽ | Grupo 4-8 personas, cualquier dirección |
| Clase privada (Индивидуальное занятие) | 2500 ₽ | A solas con el instructor, cualquier dirección, reagenda 24h antes |

## Análisis de Precios
- Precio por clase (abono 8): 487.5 ₽
- Precio por clase (abono 12): 433.3 ₽
- Ahorro con abono 12 vs individual: ~28%
