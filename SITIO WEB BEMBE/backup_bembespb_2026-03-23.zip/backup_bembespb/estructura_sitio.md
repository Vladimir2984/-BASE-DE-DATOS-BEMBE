# Backup - Estructura del Sitio bembespb.ru
## Fecha: 2026-03-23

# Estructura de URLs y Páginas

## Páginas Principales
| URL | Descripción |
|-----|-------------|
| / | Página principal |
| /dance-styles/ | Estilos de baile |
| /nabori_grupi/ | Inscripciones a grupos |
| /raspisanie/ | Horario |
| /price2/ | Precios |
| /prepodavateli/ | Profesores |
| /afrokubinskaya-shou-gruppa-bembe/ | Conciertos y masterclasses |
| /kontakty/ | Contactos |
| /statii/ | Blog |
| /wp-admin/ | Panel de administración |

## Estilos de Baile (Subpáginas)
| URL | Estilo |
|-----|--------|
| /dance-style/salsa/ | Salsa Cubana |
| /dance-style/afro/ | Afro |
| /dance-style/rumba/ | Rumba Cubana |
| /dance-style/reggaeton/ | Reggaetón |
| /dance-style/lady_style/ | Lady Style |
| /dance-style/bachata/ | Bachata |
| /dance-style/proshkin/ | Percusión |

## Artículos del Blog (Recientes)
1. /statii/mozhno-li-nachinayushhim-tanczoram-kubinskoj-salsy-poseshhat-salsa-vecherinki/
2. /statii/mozhno-li-obuchatsya-kubinskoj-salse-esli-net-svoego-partnera/
3. /statii/chto-takoe-soczialnye-latinoamerikanskie-tanczy/
4. /statii/kakie-sushhestvuyut-vidy-kubinskoj-rumby/
5. /statii/zachem-nuzhny-individualnye-zanyatiya-po-salse-ili-bachate/

## Recursos del Tema
- Tema: `/wp-content/themes/bembespb/`
- Imágenes tema: `/wp-content/themes/bembespb/assets/img/`
- Uploads: `/wp-content/uploads/2022/04/`

## Información Técnica
- CMS: WordPress
- Protocolo: HTTPS
- Copyright: © 2020 Bembe
- Idiomas detectados: Ruso, Español (parcial)

## Problemas Detectados
1. ⚠️ URL /kontakti/ retorna 404 (la correcta es /kontakty/)
2. ⚠️ Copyright desactualizado (2020)
3. ⚠️ Mezcla de idiomas en la interfaz
