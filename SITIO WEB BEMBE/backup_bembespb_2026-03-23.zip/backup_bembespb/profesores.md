# Backup - Profesores BEMBÉ
## Fecha: 2026-03-23

# Преподаватели (Profesores)

## 1. Ия Баваль (Iya Baval)
**Cargo:** Coreógrafa, profesora, directora de la escuela

**Formación:** Educación artística obtenida en Cuba

**Experiencia:**
- 2012-2015: Formación en "Conjunto Folklorico Nacional de Cuba" y "Teatro América"
- 2013: Fundadora del colectivo "Collibrí"
- 2014-2015: Pareja del bailarín cubano Israel Gutiérrez

**Educación:** Lingüista - profesora y traductora de español

**Logros:**
- 2015: Fundó la Escuela BEMBÉ
- 2016: Ganadora Salsa Night Awards-2015 "Escuela Debut"

**Estilos:** Salsa cubana, Bachata, Rumba cubana, Afro

---

## 2. Ildemar Rodríguez
**Cargo:** Profesor con experiencia internacional

**Credenciales:** Bailarín profesional acreditado por la Comisión Nacional de Cultura de Cuba

**Experiencia:**
- 2006-2017: Diversas compañías en Cuba
- Desde 2017: Profesor en BEMBÉ San Petersburgo

**Estilos:** Salsa cubana, Bachata

---

## 3. Mijaíl Proshkin
**Cargo:** Profesor de percusión cubana y piano

**Formación:**
- 1988: Colegio Musical de San Petersburgo (piano jazz)

**Logros:**
- Categoría Superior como Profesor (2010)
- Múltiples premios con "SPB Percussion Club"
